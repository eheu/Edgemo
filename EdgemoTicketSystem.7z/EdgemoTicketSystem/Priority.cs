﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EdgemoTicketSystem
{
    class Priority
    {
        public string ID { get; set; }
        public string priorityName { get; set; }
    }
}
