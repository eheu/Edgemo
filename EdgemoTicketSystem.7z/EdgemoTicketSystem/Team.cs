﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EdgemoTicketSystem
{
    public class Team
    {
        public string ID { get; set; }
        public string TeamName { get; set; }
        public string ManagerID { get; set; }
    }
}
