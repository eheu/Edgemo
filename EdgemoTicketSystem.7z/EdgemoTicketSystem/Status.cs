﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EdgemoTicketSystem
{
    class Status
    {
        public string ID { get; set; }
        public string statusName { get; set; }
    }
}
